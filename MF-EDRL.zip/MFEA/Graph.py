import copy
import math
import random
import time

import matplotlib.pyplot as plt
import networkx as nx
import numpy
import numpy as np
import torch
import scipy.sparse as sp

# from Agent import device


device = torch.device("cuda:3" if torch.cuda.is_available() else "cpu")


# ***class Graph***
# 保存图的基本信息，在网络嵌入时使用，强化学习中不会用到
class Env:
    def __init__(self, file_path: str, embedding_path: str):
        file_path = '../data/RW0.5.txt'
        embedding_path = '../data/RW0.5_embedding.txt'
        self.graph = self.build_Graph(file_path)  # 一张基于networkx的图

        self.graph_direct = self.build_Graph2(file_path)#一张有向图
        self.num_node = self.graph.number_of_nodes()
        self.node = [n for n, _ in self.graph.nodes(data=True)]
        self.node.sort()
        self.node = torch.tensor(self.node, dtype=torch.int)  # 节点的集合

        self.edges = [[u, v, w] for u, v, w in self.graph.edges(data=True)]  # 边的集合
        self.degree1 = [[n, d] for n, d in self.graph.degree]
        self.dir_degree = [[n, d] for n, d in self.graph_direct.out_degree]
        #[['A', 6], ['B', 4], ['C', 3], ['D', 6], ['E', 3], ['F', 4], ['G', 5], ['H', 1]]
        self.degree1.sort(key=lambda x: x[0])
        self.dir_degree.sort(key=lambda x: x[0])
        self.degree = torch.tensor([d for n, d in self.degree1])  # 每个节点的度
        self.dir_degree= torch.tensor([d for n, d in self.dir_degree])  # 每个节点的度
        self.embedding = torch.tensor(np.loadtxt(embedding_path)).T  # 网络嵌入后的结果
        self.dim_embedding = self.embedding.size(0)  # 嵌入的总维度

        self.state = torch.zeros((self.num_node, 1)).to(device)  # 每个节点的状态
        self.selectdFlag = list(map(lambda x: x == 0, np.zeros(self.num_node)))  # 节点是否被选中，True表示没有被选中过
        self.allreward = 0  # 每个问题的总奖励
        self.done = False  # 每个问题的终止信号


    def build_Graph(self, file_path: str):
        print(file_path)
        graph = nx.Graph()
        graphData = np.loadtxt(file_path)
        for edge in graphData:
            u=int(edge[0]-1)
            v=int(edge[1]-1)
            # u = int(edge[0])
            # v=int(edge[1])
            graph.add_edge(u,v,weight=0.1)
        print('graph is created')
        return graph

    def build_Graph2(self, file_path: str):
        graph = nx.DiGraph()
        graphP = nx.DiGraph()
        graphData = np.loadtxt(file_path)
        for u,v in graphData:
            u=int(u)-1
            v=int(v)-1
            # u = int(u)
            # v=int(v)
            graph.add_edge(u,v)
        nodesList = list(graph.nodes())  # 把点的id映射到0~n-1
        nodeMap = dict()
        index = 0
        for node in nodesList:
            nodeMap[node] = index
            index += 1
        edges1 = np.array([])
        for edge in graph.edges():
            u, v = edge
            p = 0.1
            u = nodeMap[u]
            v = nodeMap[v]
            edges1 = np.append(edges1, (u, v, p))
            graphP.add_edge(u, v, weight=p)
        edges1 = edges1.reshape((len(graphP.edges()), 3))
        return graphP

###当前使用版本，获取模型的输入
    def state2input2(self):
        input = torch.vstack((self.embedding, self.dir_degree, self.degree)).T.unsqueeze(0)
        return input.to(device)

class EnvMinNode(Env):
    def __init__(self, file_path: str, embedding_path: str):
        super(EnvMinNode, self).__init__(file_path, embedding_path)

    # 计算已经影响到的边
    def getInfluence(self, action):
        self.state[action] = 1
        edge = self.graph1.degree(action)
        for neigh in self.graph.neighbors(action):
            self.coverlist[neigh] += 1
            if self.coverlist[neigh] == self.degree[neigh] and self.state[neigh] == 1:
                self.state[neigh] = 0
                for j in list(self.graph.neighbors(neigh)):
                    self.coverlist[j] -= 1
        self.graph1.remove_node(action)
        return edge / self.num_node

    def step(self, action):
        self.selectdFlag[action] = False  # 更改节点状态
        if self.graph1.degree(action) == 0:
            reward = 0
            next_state = self.state
            return next_state, reward, self.done, None

        self.document.append(action)
        reward = self.getInfluence(action)
        self.done=nx.is_empty(self.graph1)
        return self.state, reward, self.done, None


    def getreward(self):
        return (self.graph.number_of_nodes()-self.state.sum().item())#完成任务剔除的无关节点的数量








    def reset(self):
        self.done = False
        self.state = torch.zeros((self.num_node, 1)).to(device)
        self.coverlist = torch.zeros((self.num_node, 1)).to(device)
        self.selectdFlag = list(map(lambda x: x == 0, np.zeros(self.num_node)))
        self.graph1 = copy.deepcopy(self.graph)
        self.document=[]#用于记录种子节点
        return self.state


class EnvIM(Env):
    def __init__(self, file_path: str, embedding_path: str, K: int = 10):
        super(EnvIM, self).__init__(file_path, embedding_path)
        self.K = K  # 需要挑选的节点
        self.seeds = set()  # 已经选中的节点
        self.local_inf_list = np.zeros(self.num_node) -1
        self.onehop_list = np.zeros(self.num_node) -1


    def step(self, action):

        self.state[action] = 1
        self.selectdFlag[action] = False
        self.seeds.add(action)  # 更新seeds集合
        self.document.append(action)

        if self.K <= len(self.seeds):
            self.done = True

        reward = self.getInfluence(self.seeds) - self.allreward
        self.allreward += reward
        reward = torch.tensor(reward, dtype=torch.float).unsqueeze(0)
        return self.state, reward, self.done, None

    def getreward(self):
        return self.allreward

    def reset(self):
        self.done = False
        self.seeds.clear()
        self.allreward = 0
        self.state = torch.zeros((self.num_node, 1)).to(device)
        self.reward_node = torch.zeros(self.num_node)
        self.selectdFlag = list(map(lambda x: x == 0, np.zeros(self.num_node)))
        self.local_inf_list = np.ones(self.num_node) * -1
        self.onehop_list = np.ones(self.num_node) * -1
        self.document = []
        return self.state

    def getInfluence(self,S):
        influence = 0
        for s in S:
            influence += self.getLocalInfluence(s)
        influence -= self.getEpsilon(S)
        for s in S:
            Cs = set(self.graph_direct.successors(s))
            S1 = S & Cs
            for s1 in S1:
                influence -= self.graph_direct[s][s1]['weight'] * self.getOneHopInfluence(s1)
        return influence

    # one node local influence
    def getLocalInfluence(self, node):
        if self.local_inf_list[node] >= 0:#等于要不要
            return self.local_inf_list[node]
        result = 1
        Cu = set(self.graph_direct.successors(node))

        for c in Cu:
            temp = self.getOneHopInfluence(c)
            Cc = set(self.graph_direct.successors(c))
            if node in Cc:  # if egde (c,node) exits
                temp = temp - self.graph_direct[c][node]['weight']
            temp = temp * self.graph_direct[node][c]['weight']
            result += temp

        self.local_inf_list[node] = result
        return result

    # input a node
    def getOneHopInfluence(self, node):

        if self.onehop_list[node] >= 0:  # 等于要不要
            return self.onehop_list[node]
        result = 1
        for c in self.graph_direct.successors(node):
            result += self.graph_direct[node][c]['weight']
        self.onehop_list[node] = result
        return result

    # input a set of nodes
    def getEpsilon(self, S):
        result = 0
        for s in S:
            Cs = set(self.graph_direct.successors(s))  # neighbors of node s
            S1 = Cs - S
            for c in S1:
                Cc = set(self.graph_direct.successors(c))  # neighbors of node c
                S2 = Cc & S
                result += (0.01 * len(S2))
        return result
class Nrobust(Env):
    def __init__(self,file_path,embedding_path:str):
        super(Nrobust, self).__init__(file_path,embedding_path)

    def get_void(self, action):
        count = self.graph2.number_of_nodes()
        for neigh in list(self.graph2.neighbors(action)):
            self.state[neigh] = 1
            self.selectdFlag[neigh] = False
            self.graph2.remove_node(neigh)
        self.graph2.remove_node(action)
        return (count-self.graph2.number_of_nodes())/self.num_node

    def getreward(self):
        return self.num_node-len(self.graph2.subgraph(max(nx.connected_components(self.graph2), key=len)))

    def step(self, action):


        self.state[action] = 1
        self.selectdFlag[action] = False
        self.seeds += 1
        if self.seeds >= math.ceil(0.01*self.num_node):
            self.done = True
        self.document.append(action)


        reward = self.get_void(action)  # 除最大连通，回报防止超过1
        reward = torch.tensor(reward, dtype=torch.float).unsqueeze(0)

        return self.state, reward, self.done, None

    def reset(self):
        self.markreward = [0]
        self.done = False
        self.graph2 = copy.deepcopy(self.graph)
        self.seeds = 0
        self.state = torch.zeros((self.num_node, 1)).to(device)  # n*1
        self.selectdFlag = list(map(lambda x: x == 0, numpy.zeros(self.num_node)))
        self.document=[]
        return self.state


class Minset(Env):
    def __init__(self, file_path: str, embedding_path: str):
        super(Minset, self).__init__(file_path, embedding_path)



    def getreward(self):
        return self.num_node - self.seeds

    def control(self, action):
        for neigh in self.graph[action]:  # 覆盖所有邻居
            self.cover_list[neigh] = 1
            self.selectdFlag[neigh] = False
            self.state[neigh] = 1
        reward = (self.cover_list.sum() - self.cover_sum) / self.num_node
        self.cover_sum = self.cover_list.sum()
        return reward  # 被支配的节点数

    def step(self, action):

        self.state[action] = 1

        self.selectdFlag[action] = False
        self.seeds += 1
        self.document.append(action)
        self.cover_list[action] = 1
        reward = self.control(action)  # 一个是之前的，一个是最新的覆盖数，reward为插值
        if self.cover_sum == self.num_node:
            self.done = True
        return self.state, reward, self.done, None

    def reset(self):

        self.done = False
        self.cover_sum = 0
        self.cover_list = np.zeros(self.num_node)
        self.state = torch.zeros((self.num_node, 1)).to(device)
        self.seeds = 0
        self.selectdFlag = list(map(lambda x: x == 0, np.zeros(self.num_node)))
        self.document = []
        return copy.deepcopy(self.state)


class Abnormal(Env):
    def __init__(self, file_path, embedding_path: str):
        super(Abnormal, self).__init__(file_path, embedding_path)


    def getreward(self):
        return self.num_node - self.allreward


    def select(self, action):
        reward = (1 / (self.graph2.degree(action) + 1))
        for neigh in list(self.graph2[action]):
            self.allreward += 1
            self.selectdFlag[neigh] = False
            self.graph2.remove_node(neigh)
        return reward

    def step(self, action):

        self.selectdFlag[action] = False
        self.state[action] = 1
        reward = self.select(action)  # 一个是之前的，一个是最新的覆盖数，reward为插值
        self.document.append(action)
        if nx.is_empty(self.graph2):
            self.done = True  # 先判断，不然最后一个节点会消失,放前面selectflag会报错，这就是选点策略了，硬要选度大的


        return self.state, reward, self.done, None

    def reset(self):
        self.done = False
        self.nun_list = torch.zeros(self.num_node)
        self.graph2 = copy.deepcopy(self.graph)
        self.state = torch.zeros((self.num_node, 1)).to(device)
        self.allreward = 0
        self.selectdFlag = list(map(lambda x: x == 0, np.zeros(self.num_node)))
        self.document = []
        return self.state