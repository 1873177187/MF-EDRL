import copy
import math

import numpy as np
import torch


class Distance1:
    def __init__(self, popu: list, n: int):  # n用于区别初始化还是后代，任务评估会不同
        self.n = n
        self.popu = popu
        self.list2 = []
        self.crowdedfitness = self.crowded(popu)
        self.value1 = self.crowdedfitness[:, 0]
        self.value2 = self.crowdedfitness[:, 1]
        self.value3 = self.crowdedfitness[:, 2]
        self.value4 = self.crowdedfitness[:, 3]
        self.value5 = self.crowdedfitness[:, 4]
        self.docu = self.getdocument(popu)
        self.docu1 = self.docu[:, 0].tolist()
        self.docu2 = self.docu[:, 1].tolist()
        self.docu3 = self.docu[:, 2].tolist()
        self.docu4 = self.docu[:, 3].tolist()
        self.docu5 = self.docu[:, 4].tolist()
        # self.mfea_sorted_solution = self.mfea_sort(self.value1, self.value2, self.value3, self.value4, self.value5)[0]
        # self.crowding_distance_values=self.crowdedresult(self.value1,self.value2,self.value3,self.value4,self.value5)
        # self.sortresult=self.sortdistance(self.crowding_distance_values,self.mfea_sorted_solution)
        # 排序后Agent最大的元素的对应下标，也就是技能
        self.mfea_sorted_solution, self.skills = self.mfea_sort(self.value1, self.value2, self.value3, self.value4, self.value5)
        # 更新种群的对应技能
        # self.upgrateskill(self.popu)
        # 每个Agent对应的技能
        # 纯支配,按最优的表现,没有拥挤排序
        self.ranklist = self.ranksort(self.mfea_sorted_solution)

    def crowded(self, popu):  # 用于计算每个pop
        crowdedfitness = []
        for i in popu:
            crowdedfitness.append(i.fitness)
        crowdedfitness = np.array(crowdedfitness)
        self.crowdedfitness = crowdedfitness
        return self.crowdedfitness

    def getdocument(self, popu):
        docu = []
        for i in popu:
            docu.append(i.document)
        docu = np.array(docu)
        return docu

    def sort(self, values, sort):
        fitness = copy.copy(values)
        n = 0
        for m in sort:
            fitness[m] = n
            n += 1
        return fitness

    def mfea_sort(self, value1, value2, value3, value4, value5):  # 在这里考虑的是初始化用的，不是子代更新后的按技能评估,第一代需要评估技能
        sort1 = self.sort(value1, np.argsort(value1))
        sort2 = self.sort(value2, np.argsort(value2))
        sort3 = self.sort(value3, np.argsort(value3))
        sort4 = self.sort(value4, np.argsort(value4))
        sort5 = self.sort(value5, np.argsort(value5))
        sortall = np.array(list(zip(sort1, sort2, sort3, sort4, sort5)))
        if self.n == 0:
            rank = []
            skillfactor = []
            for i in range(len(sortall)):
                a = max(sortall[i])
                s = list(sortall[i])
                skillfactor.append(s.index(a))
                rank.append(a)
            list1 = []
            for i in range(len(rank)):
                list2 = []
                for j in range(len(rank)):
                    if rank[j] == i:
                        list2.append(j)
                if list2 != []:
                    list1.append(list2)
        if self.n != 0:  # 按继承技能评估
            rank = []
            skillfactor = []
            for i in range(len(sortall)):
                a = (sortall[i][self.popu[i].skillfactor])
                # s = list(sortall[i])
                # skillfactor.append(s.index(a))
                rank.append(a)
            list1 = []
            for i in range(len(rank)):
                list2 = []
                for j in range(len(rank)):
                    if rank[j] == i:
                        list2.append(j)
                if list2 != []:
                    list1.append(list2)
        front1 = list(reversed(list1))
        self.mfea_sorted_solution = front1
        self.skill = skillfactor
        return self.mfea_sorted_solution, self.skill  # self.mfea_sorted_solution按技能最优排序后的结果

    def index_of(self, a, list):
        for i in range(0, len(list)):
            if list[i] == a:
                return i
        return -1

    def sort_by_values(self, list1, values):  # list为下标序列,values为值序列
        vlluecopy = copy.copy(values)
        sorted_list = []
        while (len(sorted_list) != len(list1)):  # 遍历len(list1)次
            if self.index_of(min(vlluecopy), vlluecopy) in list1:
                sorted_list.append(self.index_of(min(vlluecopy), vlluecopy))  # 查找该层次中的最小值所在的索引
            vlluecopy[
                self.index_of(min(vlluecopy),
                              vlluecopy)] = math.inf  # math.inf 浮点正无限(设置最小的(边界))的值为无穷,当找不到的时候设置最后一个为浮点正无限(return -1)
        return sorted_list

    # def crowding_distance(self,values1, values2,values3,values4,values5, front1):  # 注意:此处front是一维列表形式,每个层次序号
    #     distance = [0 for i in range(0, len(front1))]  # 初始化该层个体距离集合,且初值为0
    #     sorted1 = self.sort_by_values(front1, values1[:])  # 逐层排序，便于计算拥挤距离
    #     # 返回函数1该层最小的索引(并设置好了无穷)
    #     sorted2 = self.sort_by_values(front1, values2[:])
    #     sorted3 = self.sort_by_values(front1, values3[:])
    #     sorted4 = self.sort_by_values(front1, values4[:])
    #     sorted5 = self.sort_by_values(front1, values5[:])
    #     # 返回函数2该层最小的索引(并设置好了无穷)
    #     distance[0] = 4444444444444444  # 初始化(正无穷)
    #     distance[len(front1) - 1] = 4444444444444444  # 初始化(正无穷)
    #     for k in range(1, len(front1) - 1):  # 求函数1的拥挤度#这里max不知道为什莫用不同目标上的差
    #         distance[k] = distance[k] + (values1[sorted1[k + 1]] - values1[sorted1[k - 1]]) / (
    #                     max(values1) - min(values1))
    #     for k in range(1, len(front1) - 1):  # 加上函数2的拥挤度
    #         distance[k] = distance[k] + (values2[sorted2[k + 1]] - values2[sorted2[k - 1]]) / (
    #                     max(values2) - min(values2))
    #     for k in range(1, len(front1) - 1):  # 加上函数2的拥挤度
    #         distance[k] = distance[k] + (values3[sorted3[k + 1]] - values3[sorted3[k - 1]]) / (
    #                     max(values3) - min(values3))
    #     for k in range(1, len(front1) - 1):  # 加上函数2的拥挤度
    #         distance[k] = distance[k] + (values4[sorted4[k + 1]] - values4[sorted4[k - 1]]) / (
    #                 max(values4) - min(values4))
    #     for k in range(1, len(front1) - 1):  # 加上函数2的拥挤度
    #         distance[k] = distance[k] + (values5[sorted5[k + 1]] - values5[sorted5[k - 1]]) / (
    #                 max(values5) - min(values5))
    #     return distance  # 返回改层拥挤距离集
    #
    # def crowdedresult(self, value1, value2,value3,value4,value5):
    #     crowding_distance_values = []  # 定义拥挤距离值
    #     for i in range(0, len(self.mfea_sorted_solution)):  # 遍历快速非支配排序法产生的分级结果集
    #         crowding_distance_values.append(self.crowding_distance(value1, value2,value3,value4,value5,
    #                                                                self.mfea_sorted_solution[i][
    #                                                                :]))  # 计算拥挤距离 (高级用法[:](￣▽￣)~*)
    #     # 求出每层的拥挤距离值并集中到crowding_distance_values
    #     return crowding_distance_values

    # def sortdistance(self, crowding_distance_values, mfea_sorted_solution):
    #     sortlist = []
    #     for i, j in zip(crowding_distance_values, mfea_sorted_solution):
    #         a = sort_together([i, j])[1]
    #         y = list(reversed(a))
    #         sortlist.append(y)
    #     list1 = []
    #     for i in sortlist:
    #         for j in i:
    #             list1.append(j)
    #     return list1 # 实现按rank,又按拥挤距离排序
    # #单纯的最优排序，不涉及到拥挤
    def ranksort(self, mfea_sorted_solution):
        ranklist = []
        for i in range(len(mfea_sorted_solution)):
            for j in mfea_sorted_solution[i]:
                ranklist.append(j)
        return ranklist
    # def upgrateskill(self,popus):
    #     for pop in popus:
    #         index=popus.index(pop)
    #         pop.skillfactor=self.skills[index]
