###***采用差分进化算法时，使用的主函数，
# 是深度学习，就是网络参数的进化学习，调用NetworkEvolution里的函数
import argparse
import os
import torch
import numpy as np
import time
from Agent import Agent
from NetworkEvolution2 import SSNE
from Graph import EnvIM,EnvMinNode,Nrobust,Minset,Abnormal
from Memory import  Memory
from mfeacrowded import Distance1

parser = argparse.ArgumentParser(description='MFEA')
parser.add_argument("--popu_num", type=int, default=100,
                    help="which GPU to use. Set -1 to use CPU.")
args = parser.parse_args()

capacity=10000
episodes=200
popu_num=args.popu_num
save_time=10

memory_IM=Memory(capacity)#buffer-size每次有放回的数量
memory_Min=Memory(capacity)
memory_Nb=Memory(capacity)
memory_Minset=Memory(capacity)
memory_Ab=Memory(capacity)


embedding_dim=[64]



# root_Path=['./data/Elegans']
# graph_Path=['/elegan.txt']
# embedding_Path=['/elegan0']
# model_type=['/MFGA_elegan_x8']#修改最后面数字即可

# root_Path=['./data/Email']
# graph_Path=['/email.txt']
# embedding_Path=['/email0']
# model_type=['/MFGA_email_x3']#修改最后面数字即可

root_Path=['./data/RW0.5']
graph_Path=['/0.1.txt']
embedding_Path=['/0.1']
model_type=['/MFGA_0.1_x7']#修改最后面数字即可




# root_Path=['./data/GN0.4']
# graph_Path=['/0.4.txt']
# embedding_Path=['/0.4']
# model_type=['/MFGA_0.4_x10']#修改最后面数字即可

# root_Path=['./data/LFR0.2']
# graph_Path=['/0.2.txt']
# embedding_Path=['/0.2']
# model_type=['/MFGA_0.2_1']#修改最后面数字即可

# root_Path=['./data/LFR0.3']
# graph_Path=['/0.3.txt']
# embedding_Path=['/0.3']
# model_type=['/MFGA_0.3_x9']#修改最后面数字即可

# root_Path=['./data/Pgp']
# graph_Path=['/pgp.txt']
# embedding_Path=['/pgp0']
# model_type=['/MFGA_pgp_x5']#修改最后面数字即可

# root_Path=['./data/Polbooks']
# graph_Path=['/polbooks.txt']
# embedding_Path=['/polbooks0']
# model_type=['/MFGA_polbooks_x8']#修改最后面数字即可



# root_Path=['./data/Power']
# graph_Path=['/power.txt']
# embedding_Path=['/power0']
# model_type=['/MFGA_power_x1']#修改最后面数字即可

# root_Path=['./data/Wikip']
# graph_Path=['/wikip.txt']
# embedding_Path=['/wikip0']
# model_type=['/MFGA_wikip_x3']#修改最后面数字即可


def save_popu(path:str,populist:list):#poplist:popu
    for i,popu in enumerate(populist):
        torch.save(popu.policy_model.state_dict(),path+'/threemodel_'+str(i)+'.pt')
def load_model(path:str,populist:list,evolve):#populist:生成的10个Agent对象
    #load_model(root_Path[Index]+model_type[modelIndex],popu,evolve)
    for i,popu in enumerate(populist):
        try:
            popu.policy_model.load_state_dict(torch.load(path+'/threemodel_'+str(i)+'.pt'))
            popu.fitness=evolve.getFitness(popu)
        except FileNotFoundError:
            continue
def save_fitness(path,fitnessList,name):
    fitnessList=np.array(fitnessList)
    if name=='result':
        np.savetxt(path+'/'+name+'.txt',fitnessList)
    else:
        np.savetxt(path + '/' + name + '.txt', fitnessList,fmt="%d")


if __name__ == '__main__':
    Index=0
    modelIndex=0#每次运行生成的文件序号
    fitnessList = []

    nameList=['IM','Min-Node','Nb','Minset','Ab']
    IM_Env=EnvIM(root_Path[Index]+graph_Path[Index],root_Path[Index]+embedding_Path[Index],K=10)
    Min_Env=EnvMinNode(root_Path[Index]+graph_Path[Index],root_Path[Index]+embedding_Path[Index])    ##创建两个环境的对象
    Nb_Env=Nrobust(root_Path[Index]+graph_Path[Index],root_Path[Index]+embedding_Path[Index])
    Minset_Env=Minset(root_Path[Index]+graph_Path[Index],root_Path[Index]+embedding_Path[Index])
    Ab_Env=Abnormal(root_Path[Index]+graph_Path[Index],root_Path[Index]+embedding_Path[Index])

    EnvList = (IM_Env, Min_Env,Nb_Env,Minset_Env,Ab_Env)
    memoryList = (memory_IM, memory_Min,memory_Minset,memory_Nb,memory_Ab)
    dones=()
    agent=Agent(IM_Env.num_node,IM_Env.dim_embedding+1,len(EnvList))   #生成agent对象
    evolve=SSNE(EnvList,memoryList) #生成进化模块
    time_begin = time.time()
    popu=evolve.createpopu # popu=popus
    popu=popu(popu_num)#创建10个种群，10个Agent对
    mfeacrowded=Distance1(popu,1)
    popusort = mfeacrowded.ranklist
    #popusort =crowdingdistance.sortresult
    max1 = []
    seed1=[]
    one = mfeacrowded.value1.tolist()
    one_1 = max(one)
    max1.append(one_1)
    seed1.append(mfeacrowded.docu1[one.index(one_1)])

    max2 = []
    seed2 = []
    two = mfeacrowded.value2.tolist()
    two_1 = max(two)
    max2.append(two_1)
    seed2.append(mfeacrowded.docu2[two.index(two_1)])

    max3 = []
    seed3 =[]
    three = mfeacrowded.value3.tolist()
    three_1 = max(three)
    max3.append(three_1)
    seed3.append(mfeacrowded.docu3[three.index(three_1)])

    seed4 = []
    max4 = []
    four = mfeacrowded.value4.tolist()
    four_1 = max(four)
    max4.append(four_1)
    seed4.append(mfeacrowded.docu4[four.index(four_1)])

    max5 = []
    seed5 =[]
    five = mfeacrowded.value5.tolist()
    five_1 = max(five)
    max5.append(five_1)
    seed5.append(mfeacrowded.docu5[five.index(five_1)])
    #
    # if os.path.exists(root_Path[Index]+model_type[modelIndex]):       #尝试读取现有的模型信息
    #     load_model(root_Path[Index]+model_type[modelIndex],popu,evolve)
    # else:
    #     os.makedirs(root_Path[Index]+model_type[modelIndex])

    for i in range(episodes+1):#200+1，进化的代数
        next_popu = evolve.epoch(popu)
        popu.extend(next_popu)#将新旧种群合并
        mfeacrowded = Distance1(popu,1)
        popusort = mfeacrowded.ranklist
        one = mfeacrowded.value1.tolist()
        one_1 = max(one)
        max1.append(one_1)
        seed1.append(mfeacrowded.docu1[one.index(one_1)])

        two = mfeacrowded.value2.tolist()
        two_1 = max(two)
        max2.append(two_1)
        seed2.append(mfeacrowded.docu2[two.index(two_1)])


        three = mfeacrowded.value3.tolist()
        three_1 = max(three)
        max3.append(three_1)
        seed3.append(mfeacrowded.docu3[three.index(three_1)])

        four = mfeacrowded.value4.tolist()
        four_1 = max(four)
        max4.append(four_1)
        seed4.append(mfeacrowded.docu4[four.index(four_1)])

        five = mfeacrowded.value5.tolist()
        five_1 = max(five)
        max5.append(five_1)
        seed5.append(mfeacrowded.docu5[five.index(five_1)])



        last_popu=[]
        for j in popusort[0:100]:
            last_popu.append(popu[j])

        popu=last_popu


        print('round :%d\t ' % (i))
        #打印出每一代适应度最高的个体，因为前面是按适应度排序的，fitness也是2元素的，对应于每个任务的reward

        zp=[max(max1),max(max2),max(max3),max(max4),max(max5)]






        for fitness,name in zip(zp,nameList):
            print(name+':reward:%.2f'% fitness)
        result = (max(max1),max(max2),max(max3),max(max4),max(max5))
        fitnessList.append(result)
        IMseed=seed1[max1.index(max(max1))]
        Min_nodeseed=seed2[max2.index(max(max2))]
        Nbseed=seed3[max3.index(max(max3))]
        Minsetseed=seed4[max4.index(max(max4))]
        Uniseed = seed5[max5.index(max(max5))]
        if i%save_time==0:#每20次保存一次，将此时最好适应度的神经网络参数保存,会覆盖的叭，每20代，最后覆盖就是最后一代
            # save_popu(root_Path[Index]+model_type[modelIndex],popu)
            # save_fitness(root_Path[Index] + model_type[modelIndex], fitnessList,'result')
            # save_fitness(root_Path[Index] + model_type[modelIndex],IMseed,'IMseed' )
            # save_fitness(root_Path[Index] + model_type[modelIndex], Min_nodeseed, 'MVCseed')
            # save_fitness(root_Path[Index] + model_type[modelIndex], Nbseed, 'NRAseed')
            # save_fitness(root_Path[Index] + model_type[modelIndex], Minsetseed, 'MDSseed')
            print(Uniseed)
            # save_fitness(root_Path[Index] + model_type[modelIndex], Uniseed, 'MISseed')
    time_end = time.time()
    time = time_end - time_begin
    # save_fitness(root_Path[Index] + model_type[modelIndex], [time], '1-timecost')
    print('time:', time)

    from datetime import datetime
    import csv

    current_time = datetime.now()
    formatted_time = current_time.strftime('%Y%m%d%H%M%S')
    task_name = ['IM', 'MVC', 'NRA', 'MDS', 'MIS', str(popu_num), str('time:' + str(time))]
    data = [task_name, zp]
    print(formatted_time, data)
    result_path = './result/' + root_Path[0].replace('./data/', '') + '_' + str(
        popu_num) + '_' + formatted_time + '.csv'
    with open(result_path, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        for row in data:
            writer.writerow(row)


