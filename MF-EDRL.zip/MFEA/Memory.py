from collections import namedtuple
import random
Transition = namedtuple(
    'Transition', ('state', 'action', 'next_state', 'reward', 'done'))

class Memory:
    def __init__(self,capacity:int):
        self.memory=[]#用来记录每个transition
        self.position=0
        self.capacity=capacity
        self.index=0

    def push(self, *args):
        """Saves a transition."""
        if len(self.memory) < self.capacity:
            self.memory.append(None)#先将该数组的值全部设置为空，然后修改填充对应数据，memory的长度为交配池的大小
        self.memory[self.position] = Transition(*args)
        self.position = (self.position + 1) % self.capacity

    def sample(self, batch_size:int):
        return random.sample(self.memory, batch_size)#从memory中，随机取出batch_size个作为样本

    def __len__(self):
        return len(self.memory)

