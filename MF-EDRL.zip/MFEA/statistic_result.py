from pathlib import Path
import csv

import numpy as np

folder = './result/'
folder_path = Path(folder)
file_list = [str(p) for p in folder_path.rglob("*") if p.is_file() and 'Power_100' in str(p)]

print(file_list)
def read_csv(file_path):
    data = []
    with open(file_path, 'r', newline='') as csvfile:
        reader = csv.reader(csvfile)
        headers = next(reader)  # 读取标题行
        for row in reader:
            data = row
    return headers, data


out_result = list([[], [], [], [], []])

for file in file_list:
    headers, data = read_csv(file)
    for i, d in enumerate(data):
        if d != '0':
            print(d)
            out_result[i].append(d)

print(out_result)
averages = [sum(map(float, sublist))/len(sublist) if sublist else 0 for sublist in out_result]
print(headers)
print(averages)
