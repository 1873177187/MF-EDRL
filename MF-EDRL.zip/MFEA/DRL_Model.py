import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F



##***真正使用的模型
#这一步都用的到
class DRL_Model4(nn.Module):
    def __init__(self,num_node:int,dim:int,Env_nums):#节点数，维度环境数2
        super(DRL_Model4,self).__init__()
        self.dim=dim
        self.l=16
        self.k=8
        self.j=4
        self.L1=nn.Linear(dim,self.l,dtype=float)#line之后为16维
        self.L2=nn.Linear(self.l,self.k,dtype=float)     #对网络进行特征提取，直接用两层全连接层提取K维特征n*K

        self.IM_L3=nn.Linear((self.k+1),self.j,dtype=float)#n*k拼接上n*1，n*（K+1）
        self.MIN_L3=nn.Linear((self.k+1),self.j,dtype=float)
        self.Nb_L3=nn.Linear((self.k+1),self.j,dtype=float)
        self.Minset_L3=nn.Linear((self.k+1),self.j,dtype=float)
        self.Ab_L3 = nn.Linear((self.k + 1), self.j, dtype=float)

        self.IM_L4=nn.Linear((self.j),1,dtype=float)
        self.MIN_L4=nn.Linear((self.j),1,dtype=float)
        self.Nb_L4 = nn.Linear((self.j), 1, dtype=float)
        self.Minset_L4 = nn.Linear((self.j), 1, dtype=float)
        self.Ab_L4 = nn.Linear((self.j), 1, dtype=float)

    def forward(self, data, states: tuple):
        x = self.L1(data)
        x = self.L2(x)  # n*K
        x = F.relu(x)

        y1 = torch.cat((x, states[:, :, 0].unsqueeze(2)), dim=2)
        # 取state每个tensor的第一列n维，扩展对齐，拼接（x,n，1）--->(n,k+1)
        y1 = self.IM_L3(y1)
        # y1=y1.view((-1,y1.size(-2)*y1.size(-1)))
        values1, indices1 = torch.sort(self.IM_L4(y1).squeeze(-1), descending=True)

        y2 = torch.cat((x, states[:, :, 1].unsqueeze(2)), dim=2)
        y2 = self.MIN_L3(y2)
        values2, indices2 = torch.sort(self.MIN_L4(y2).squeeze(-1), descending=True)

        # y2=y1.view((-1,y2.size(-2)*y2.size(-1)))
        y3 = torch.cat((x, states[:, :, 2].unsqueeze(2)), dim=2)
        y3 = self.Nb_L3(y3)
        # Nb_output = self.Nb_L4(y3)
        values3, indices3 = torch.sort(self.Nb_L4(y3).squeeze(-1), descending=True)

        y4 = torch.cat((x, states[:, :, 3].unsqueeze(2)), dim=2)
        y4 = self.Minset_L3(y4)
        # Minset_output = self.Minset_L4(y4)
        values4, indices4 = torch.sort(self.Minset_L4(y4).squeeze(-1), descending=True)

        y5 = torch.cat((x, states[:, :, 4].unsqueeze(2)), dim=2)
        y5 = self.Ab_L3(y5)
        # Ab_output = self.Ab_L4(y5)
        values5, indices5 = torch.sort(self.Ab_L4(y5).squeeze(-1), descending=True)

        return [indices1, indices2, indices3, indices4, indices5]  # 由n*1变为1*n，一个节点一个节点分开
