import copy
import math
import random
from collections import namedtuple
import torch
import numpy
import torch.optim as optim
from DRL_Model import DRL_Model4
from Memory import Memory
from Graph import EnvIM,EnvMinNode,Nrobust,device
from model_unit import IsDone,IsSample
Transition = namedtuple(
    'Transition', ('state', 'action', 'next_state', 'reward', 'done'))
discount_rate=0.95
num_episodes=300
capacity=10000

memory_IM=Memory(capacity)#记录1000个transition
memory_Min=Memory(capacity)
memory_Nb=Memory(capacity)
memory_Si=Memory(capacity)

class Agent:
    def __init__(self,num_node:int,dim:int,Env_nums:int):                              ##batch-size，反向传播时的采样量
        self.num_node=num_node
        self.policy_model=DRL_Model4(num_node,dim,Env_nums).to(device)    #决策网络,进化任务也会用到
        self.skillfactor=-1#初始技能因素为0


    #获取下一个动作,分train模式和test模式
    #分别获取两个环境的动作
    def action(self,states:list,input,envs:tuple):
        #IM输入embedding与degree的拼接的tensor，此时输入的data是IM任务的
        outputs=self.policy_model(input,torch.hstack(states).unsqueeze(0))#这里的拼接的ststes很重要,看第146行
        return outputs#所有节点的最终得分

