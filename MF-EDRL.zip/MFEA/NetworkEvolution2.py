import copy

import numpy
import numpy as np

from Graph import Env,device
import torch
from Memory import Memory
from Agent import Agent
import random
from mfeacrowded import Distance1

#***class SSNE***
#神经网络进化模块：F：这里是针对神经网络可训练参的优化
class SSNE:
    def __init__(self,EnvList:tuple,memoryList:tuple):
        self.cross_rate=0.3    #交换概率
        self.cross1_rate = 0.9
        self.variation_rate=0.1   #变异概率
        self.EnvList=EnvList
        self.memoryList=memoryList
        self.input=self.EnvList[0].state2input2()

        ##随机生成一个种群
    def createpopu(self,n:int):#popu_num=10
        popus=[]#Agent对象
        for i in range(n):
            new_Agent=Agent(self.EnvList[0].num_node,self.EnvList[0].dim_embedding+2,len(self.EnvList))
            #这里载入一个就行，两个任务的基本数据是相同的
            # new_Agent.fitness=self.getFitness(new_Agent)[0]
            new_Agent.fitness, new_Agent.document=self.getFitness(new_Agent)
            popus.append(new_Agent)
        mfeacrowded = Distance1(popus,0)
        skills=mfeacrowded.skills
        for pop in popus:
            index=popus.index(pop)
            pop.skillfactor=skills[index]
        return popus

    #利用遗传算法优化网络，返回下一代个体
    def epoch(self,popu:list):#popu:main函数里：npopu=evolve.createpopu(popu_num)，也就是上面的popus
        next_popu=[]
        mfeacrowded = Distance1(popu,1)
        popusort = mfeacrowded.ranklist
        print('popusort:', popusort)
        popu1=[]
        for sort in popusort:
            popu1.append(popu[sort])
        popu=popu1
        popu_Num=len(popu)
        index=list(range(popu_Num))
        random.shuffle(index)#将种群打乱
        for index_i,index_j in zip(index[0::2],index[1::2]):#F：父代，将种群对半划分
            next1=copy.deepcopy(popu[index_i])#父
            next2=copy.deepcopy(popu[index_j])#母
            if popu[index_i].skillfactor==popu[index_j].skillfactor or random.random()<self.cross_rate:
                self.cross(next1,next2)               #进行交换和变异操作，产生两个个体
                if random.random()<=0.5:
                    next1.skillfactor=popu[index_i].skillfactor
                else:
                    next1.skillfactor=popu[index_j].skillfactor
                if random.random()>0.5:
                    next2.skillfactor=popu[index_i].skillfactor
                else:
                    next2.skillfactor=popu[index_j].skillfactor
            else:
                self.mutate(next1)
                next1.skillfactor=popu[index_i].skillfactor
                self.mutate(next2)
                next2.skillfactor = popu[index_j].skillfactor
            next1.fitness=self.getFitness(next1) [0] #计算评分#突变后父子代
            next2.fitness=self.getFitness(next2)[0]
            next1.document = self.getFitness(next1)[1]
            next2.document = self.getFitness(next2)[1]
            next_popu.extend([next1,next2])#F:将二者合并为一个新的popu
        return list(next_popu)

    #基因突变函数
    def mutate(self,popu):
        paras1=popu.policy_model.state_dict()#每个对象神经网络可训练参数，w可训练参数
        for key in paras1:
            W1=paras1[key]
            if len(W1.shape)==2:         # no bias
                crossFlag=numpy.random.random((W1.size(0),W1.size(1)))
                crossFlag=torch.tensor(np.array(list(map(lambda x:x<self.variation_rate, crossFlag))))
                for i in range(W1.size(0)):#遍历该key的每一行
                    line=W1[i]#单独每个key的参数 L1.weight,torch.Size([16, 33])
                    flagTmp=crossFlag[i]#第i行的mask
                    indexList=torch.tensor((range(len(line))))[flagTmp]#该行应用mask之后的状态，留下的是突变位置
                    for j in indexList:#产生突变值
                        num=random.random()
                        if num<0.8:
                            line[j]+=0.5*torch.randn(1).squeeze(0) #突变值为标准分布
                        elif num <0.9:
                            line[j]+=torch.randn(1).squeeze(0)
                        else:
                            line[j]=torch.randn(1).squeeze(0)
            else:                              #bias
                crossFlag=numpy.random.random(W1.size(0))
                crossFlag=torch.tensor(np.array(list(map(lambda x:x<self.variation_rate, crossFlag))))
                indexList=torch.tensor((range(len(W1))))[crossFlag]
                for i in indexList:
                        if crossFlag[i]:
                            W1[i]+=torch.randn(1).squeeze(0) #突变值为标准分布


    #选择两个个体进行交叉
    #F:每一层交叉变异
    def cross(self,pop1,pop2):#差分变异的个体和原本的个体
        paras1=pop1.policy_model.state_dict()
        paras2=pop2.policy_model.state_dict()
        for key1,key2 in zip(paras1,paras2):
            W1=paras1[key1]#每一层（名称）的权重矩阵
            W2=paras2[key2]
            if len(W1.shape)==2:
                crossFlag=numpy.random.random((W1.size(0),W1.size(1)))#变异点，生成w1形状的随机矩阵

            elif len(W1.shape)==1:#bias的tensor
                ##生成交叉基因的mask
                crossFlag=numpy.random.random(W1.size(0))
            crossFlag=torch.tensor(np.array(list(map(lambda x:x<self.cross_rate, crossFlag))))
            W1[crossFlag], W2[crossFlag] = W2[crossFlag], W1[crossFlag]

    def getFitness(self, popu):
        # time3_begin = time.time()
        rewardList = []
        document = []#记录节点
        states = []
        for env in self.EnvList:
            states.append(env.reset())
        # time3_end = time.time()
        # time3 = time3_end - time3_begin
        # print('outputs时间:', time3)

        outputs = popu.action(states, self.input, self.EnvList)  # 对应任务的action,这里的Envlist是初始的10个种群

        for i in range(self.EnvList[0].num_node):
            next_states = []
            for env, memory, state, output in zip(self.EnvList, self.memoryList, states, outputs):
                action = output[0][i].item()
                if env.selectdFlag[action] is False or env.done:
                    next_states.append(env.state)  # 问题已经结束，跳过
                    continue
                next_state, reward, done, info = env.step(action)
                next_states.append(next_state)  # 保存单个问题的奖励
                memory.push(state, action, next_state, reward, done)  # 存放到经验池
            states = next_states
        for env in self.EnvList:
            rewardList.append(env.getreward())  # 评估结束，获取适应度，适应度就是该任务获得的奖励
            document.append(env.document)
        return rewardList,document  # 长度为2,表两个任务结束时各自的reward







