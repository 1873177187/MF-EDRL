import torch
from Graph import Env
import numpy as np
##两个问题是否都结束了
def IsDone(EnvList:tuple):#检查两个任务是否完成，对应的graph有self.done标志
    for env in EnvList:
        if not env.done:
            return False
    return True
##是否从经验池中进行采样
def IsSample(memoryList:tuple,batch_size:int):
    for memory in memoryList:
        if memory.__len__()<batch_size:#如果memory的长度<一个batchsize,停止从经验池采样
            return False
    return True

##将模型参数标准化为[-1,1]
def standardModel(model):
    para=model.state_dict()#每一层的参数
    keys=para.keys()#para的键
    for key in keys:
        W=para[key].T#将值抽出来并转置
        if len(W.shape)==2:
            for i,line in enumerate(W):
                line=2*(line-line.min())/(line.max()-line.min())-1
                W[i]=line
##根据顶点编号，转换为对应的one-hot编码
def one_hot(num,length):
    mat=torch.zeros((len(num),length),dtype=float)
    for i in range(len(num)):
        mat[i][int(num[i])-1]=1
    return mat